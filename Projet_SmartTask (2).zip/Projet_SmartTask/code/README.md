# Smart Task Manager

## What is this app?

Smart Task Manager is a daily task management app with a special feature: it checks the **weather** and gives you a recommendation for each task.

---

## What does it do?

- Add your daily tasks with a date and time
- Choose whether each task is affected by weather or not
- The app fetches live weather for the city you choose
- It gives you a recommendation for each task:
  - **OK** — Task is not weather-sensitive
  - **SAFE** — Weather is fine, go ahead
  - **WARNING: Rain** — High rain probability, consider rescheduling
  - **WARNING: Heat** — Extreme heat, consider rescheduling

---

## App Components

| Part | Role |
|---|---|
| **Task** | Represents a single task (title, time, weather-sensitive?) |
| **TaskManager** | Main controller — add, remove, and view tasks |
| **WeatherService** | Fetches live weather data from the internet |
| **SchedulePlanner** | Analyzes weather and gives a recommendation for each task |
| **SmartTaskManagerFrame** | The main app window |

---

## How to Run

1. Open `src/main/java/taskmanager/ui/MainApp.java`
2. Replace `YOUR_API_KEY_HERE` with your API key
3. Run the file directly from your IDE

> To get a free API key: sign up at [openweathermap.org](https://openweathermap.org) and copy your key from **My API Keys**

---

## Code Example — Using TaskManager

```java
import taskmanager.api.TaskManager;
import taskmanager.model.Task;
import taskmanager.api.ScheduleRecommendation;
import java.time.LocalDateTime;
import java.util.List;

public class Example {
    public static void main(String[] args) {

        // 1. Build the TaskManager with your API key
        TaskManager tm = TaskManager.builder()
                .withWeatherApiKey("your_api_key_here")
                .build();

        // 2. Create and add a task
        Task task = new Task("t-001", "Morning Run",
                LocalDateTime.now().plusHours(2), true);
        tm.addTask(task);

        // 3. Get weather-aware schedule recommendations
        tm.getPlanner()
          .suggestScheduleForLocation(tm.getTasks(), "Jeddah")
          .subscribe(recommendations -> {
              for (ScheduleRecommendation r : recommendations) {
                  System.out.println(r.task().getTitle() + ": " + r.recommendation());
              }
          });
    }
}
```

**Expected output:**
```
Morning Run: SAFE - Weather conditions are suitable.
```
or
```
Morning Run: WARNING: High rain probability (85%). Consider rescheduling.
```
