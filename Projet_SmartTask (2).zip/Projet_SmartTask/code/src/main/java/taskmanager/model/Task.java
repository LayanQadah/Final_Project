package taskmanager.model;

import java.time.LocalDateTime;

/**
 * Represents a user task in the Smart Task Manager system.
 *
 * <p>A task has a unique ID, a title, an optional description,
 * a due date/time, and a flag indicating whether it is sensitive to weather conditions.
 *
 * <p><b>Thread Safety:</b> This class is NOT thread-safe. External synchronization
 * is required if instances are shared across multiple threads.
 */
public class Task {

    /** Unique identifier for this task. Set at construction and never changed. */
    private final String id;

    /** Short title describing the task (must not be null or blank). */
    private String title;

    /** Optional longer description of the task. May be null. */
    private String description;

    /** The date and time by which this task should be completed. */
    private LocalDateTime dueDateTime;

    /** True if this task should not be performed in bad weather conditions. */
    private boolean weatherSensitive;

    /**
     * Constructs a Task with the given attributes.
     *
     * <p><b>PRECONDITION:</b> id and title must not be null or blank.
     * <p><b>POSTCONDITION:</b> A valid Task object is created with the given values.
     *
     * @param id               unique identifier for the task (must not be null)
     * @param title            short description of the task (must not be null or blank)
     * @param dueDateTime      the deadline for the task (may be null)
     * @param weatherSensitive true if bad weather should warn the user
     */
    public Task(String id, String title, LocalDateTime dueDateTime, boolean weatherSensitive) {
        this.id = id;
        this.title = title;
        this.dueDateTime = dueDateTime;
        this.weatherSensitive = weatherSensitive;
    }

    /**
     * Returns the unique ID of this task.
     *
     * @return task ID; never null
     */
    public String getId() {
        return id;
    }

    /**
     * Returns the title of this task.
     *
     * @return task title; never null after a valid construction
     */
    public String getTitle() {
        return title;
    }

    /**
     * Sets a new title for this task.
     *
     * <p><b>PRECONDITION:</b> title must not be null or blank.
     * <p><b>SIDE EFFECTS:</b> Modifies this.title.
     *
     * @param title the new title (must not be null or blank)
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Returns the optional description of this task.
     *
     * @return task description, or null if not set
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the description of this task.
     *
     * <p><b>SIDE EFFECTS:</b> Modifies this.description.
     *
     * @param description optional details about the task (may be null)
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Returns the due date and time of this task.
     *
     * @return due date/time, or null if not set
     */
    public LocalDateTime getDueDateTime() {
        return dueDateTime;
    }

    /**
     * Sets the due date and time of this task.
     *
     * <p><b>SIDE EFFECTS:</b> Modifies this.dueDateTime.
     *
     * @param dueDateTime the new deadline (may be null)
     */
    public void setDueDateTime(LocalDateTime dueDateTime) {
        this.dueDateTime = dueDateTime;
    }

    /**
     * Returns whether this task is sensitive to weather conditions.
     *
     * @return true if the task should be warned against bad weather
     */
    public boolean isWeatherSensitive() {
        return weatherSensitive;
    }

    /**
     * Sets the weather sensitivity flag for this task.
     *
     * <p><b>SIDE EFFECTS:</b> Modifies this.weatherSensitive.
     *
     * @param weatherSensitive true if bad weather should generate a warning
     */
    public void setWeatherSensitive(boolean weatherSensitive) {
        this.weatherSensitive = weatherSensitive;
    }
}
