package taskmanager.model;

import java.time.LocalDateTime;

/**
 * Immutable snapshot of weather conditions for a specific location and time.
 *
 * <p>Created by {@code WeatherService} after parsing the response from the
 * OpenWeatherMap API. All fields are set at construction and cannot be changed.
 *
 * <p><b>Thread Safety:</b> This class is immutable and therefore thread-safe.
 */
public class WeatherForecast {

    /** Name of the city or location this forecast applies to. */
    private final String location;

    /** The date and time when this forecast was retrieved. */
    private final LocalDateTime time;

    /** Current temperature in degrees Celsius. */
    private final double temperatureCelsius;

    /** Weather condition string from the API (e.g., "Rain", "Clear", "Clouds"). */
    private final String condition;

    /**
     * Estimated probability of precipitation (value between 0.0 and 1.0).
     * Derived from the weather condition since the free API tier does not provide it directly.
     */
    private final double precipitationProbability;

    /**
     * Constructs a WeatherForecast with all weather attributes.
     *
     * <p><b>PRECONDITION:</b> location and condition must not be null.
     * precipitationProbability must be between 0.0 and 1.0 (inclusive).
     * <p><b>POSTCONDITION:</b> An immutable WeatherForecast object is created.
     *
     * @param location                 city name (must not be null)
     * @param time                     time of forecast retrieval (must not be null)
     * @param temperatureCelsius       temperature in degrees Celsius
     * @param condition                weather condition string (e.g., "Rain", "Clear")
     * @param precipitationProbability rain probability; value between 0.0 and 1.0
     */
    public WeatherForecast(String location, LocalDateTime time,
                           double temperatureCelsius,
                           String condition,
                           double precipitationProbability) {
        this.location = location;
        this.time = time;
        this.temperatureCelsius = temperatureCelsius;
        this.condition = condition;
        this.precipitationProbability = precipitationProbability;
    }

    /**
     * Returns the location name for this forecast.
     *
     * @return city name; never null
     */
    public String getLocation() {
        return location;
    }

    /**
     * Returns the time this forecast was retrieved.
     *
     * @return retrieval timestamp; never null
     */
    public LocalDateTime getTime() {
        return time;
    }

    /**
     * Returns the temperature in degrees Celsius.
     *
     * @return temperature in °C
     */
    public double getTemperatureCelsius() {
        return temperatureCelsius;
    }

    /**
     * Returns the weather condition string from the API.
     *
     * @return condition such as "Rain", "Clear", "Clouds", "Snow", or "Thunderstorm"
     */
    public String getCondition() {
        return condition;
    }

    /**
     * Returns the estimated precipitation probability.
     *
     * @return value between 0.0 (no rain) and 1.0 (certain rain)
     */
    public double getPrecipitationProbability() {
        return precipitationProbability;
    }
}
