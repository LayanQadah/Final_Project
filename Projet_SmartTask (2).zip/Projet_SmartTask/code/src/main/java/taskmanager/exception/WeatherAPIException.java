package taskmanager.exception;

/**
 * Thrown when a weather API request fails — due to a network error,
 * invalid API key, or an unexpected response from the weather service.
 *
 * <p>Callers may choose to retry the operation or display a fallback message to the user.
 */
public class WeatherAPIException extends RuntimeException {

    /**
     * Constructs a WeatherAPIException with a message and the root cause.
     *
     * <p><b>PRECONDITION:</b> message is not null. cause may be null if the root cause is unknown.
     * <p><b>POSTCONDITION:</b> Exception wraps the original cause for debugging.
     * <p><b>SIDE EFFECTS:</b> None.
     *
     * @param message description of the weather API failure (must not be null)
     * @param cause   the underlying exception that caused this failure (may be null)
     */
    public WeatherAPIException(String message, Throwable cause) {
        super(message, cause);
    }
}
