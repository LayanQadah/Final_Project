package taskmanager.exception;

/**
 * Thrown when a task fails validation — for example, if its title is null or empty.
 *
 * <p>This is an unchecked exception used to enforce preconditions on task data
 * before it is added to the system.
 */
public class InvalidTaskException extends RuntimeException {

    /**
     * Constructs an InvalidTaskException with a descriptive message.
     *
     * <p><b>PRECONDITION:</b> message is not null.
     * <p><b>POSTCONDITION:</b> Exception message describes the validation failure.
     *
     * @param message description of why the task is invalid (must not be null)
     */
    public InvalidTaskException(String message) {
        super(message);
    }
}
