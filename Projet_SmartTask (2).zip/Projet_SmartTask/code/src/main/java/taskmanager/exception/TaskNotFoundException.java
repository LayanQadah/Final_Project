package taskmanager.exception;

/**
 * Thrown when a task with the specified ID cannot be found in the system.
 *
 * <p>This is an unchecked exception — callers are not required to catch it,
 * but should handle it when searching for tasks by ID.
 */
public class TaskNotFoundException extends RuntimeException {

    /**
     * Constructs a TaskNotFoundException for the given task ID.
     *
     * <p><b>PRECONDITION:</b> taskId is not null.
     * <p><b>POSTCONDITION:</b> Exception message includes the missing task ID.
     *
     * @param taskId the ID of the task that was not found (must not be null)
     */
    public TaskNotFoundException(String taskId) {
        super("Task not found: " + taskId);
    }
}
