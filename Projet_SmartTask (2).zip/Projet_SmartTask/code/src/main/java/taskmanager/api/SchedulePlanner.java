package taskmanager.api;

import java.util.List;

import reactor.core.publisher.Mono;
import taskmanager.model.Task;
import taskmanager.model.WeatherForecast;

/**
 * Generates weather-aware schedule recommendations for a list of tasks.
 *
 * <p>Each task is evaluated against current weather conditions and receives
 * one of the following recommendations: SAFE, WARNING (rain), or WARNING (heat).
 * Tasks that are not weather-sensitive always receive an "OK" recommendation.
 *
 * <p><b>Thread Safety:</b> Implementations must be thread-safe.
 */
public interface SchedulePlanner {

    /**
     * Suggests a schedule for the given tasks based on an existing weather forecast.
     *
     * <p><b>PRECONDITION:</b> tasks and forecast must not be null.
     * <p><b>POSTCONDITION:</b> Returns one recommendation per task in the input list.
     * <p><b>SIDE EFFECTS:</b> None — does not modify tasks or forecast.
     *
     * @param tasks    the list of tasks to evaluate (must not be null)
     * @param forecast the current weather forecast to use (must not be null)
     * @return {@code Mono<List<ScheduleRecommendation>>} with one entry per task
     */
    Mono<List<ScheduleRecommendation>> suggestSchedule(
            List<Task> tasks,
            WeatherForecast forecast);

    /**
     * Fetches weather for the given location, then evaluates all tasks against it.
     *
     * <p><b>PRECONDITION:</b> tasks and location must not be null; location must be a valid city name.
     * <p><b>POSTCONDITION:</b> Returns one recommendation per task. If the weather fetch fails,
     * each task receives a fallback "Weather unavailable" message instead of an error.
     * <p><b>SIDE EFFECTS:</b> May trigger a network call to fetch weather data.
     *
     * @param tasks    the list of tasks to evaluate (must not be null)
     * @param location the city name to fetch weather for (e.g., "Jeddah"; must not be null)
     * @return {@code Mono<List<ScheduleRecommendation>>} with one entry per task
     */
    Mono<List<ScheduleRecommendation>> suggestScheduleForLocation(
            List<Task> tasks,
            String location);
}
