package taskmanager.api;

import taskmanager.model.Task;

/**
 * Holds the scheduling recommendation for a single task.
 *
 * <p>Created by {@link SchedulePlanner} after evaluating a task against
 * current weather conditions.
 *
 * <p>The recommendation string will be one of:
 * <ul>
 *   <li>"OK - Task is not weather-sensitive."</li>
 *   <li>"SAFE - Weather conditions are suitable."</li>
 *   <li>"WARNING: High rain probability (...). Consider rescheduling."</li>
 *   <li>"WARNING: Extreme heat (...). Consider rescheduling."</li>
 *   <li>"Weather unavailable — please try again." (on API failure)</li>
 * </ul>
 *
 * <p><b>Thread Safety:</b> This record is immutable and therefore thread-safe.
 *
 * @param task           the task this recommendation applies to (never null)
 * @param recommendation the scheduling advice string (never null)
 */
public record ScheduleRecommendation(Task task, String recommendation) {
}
