package taskmanager.api;

import reactor.core.publisher.Mono;
import taskmanager.model.Task;
import taskmanager.model.WeatherForecast;

import java.util.List;

/**
 * The main entry point for the Smart Task Manager system.
 *
 * <p>Use {@link #builder()} to create an instance. Example:
 * <pre>
 *   TaskManager tm = TaskManager.builder()
 *       .withWeatherApiKey("your_key")
 *       .build();
 * </pre>
 */
public interface TaskManager {

    /**
     * Adds a task to the system.
     *
     * <p><b>PRECONDITION:</b> task must not be null; title must not be blank.
     * <p><b>POSTCONDITION:</b> Task is stored and visible in {@link #getTasks()}.
     *
     * @param task the task to add (must not be null)
     * @throws taskmanager.exception.InvalidTaskException if task or title is null or blank
     */
    void addTask(Task task);

    /**
     * Removes the task with the given ID from the system.
     *
     * <p><b>PRECONDITION:</b> taskId must match an existing task.
     * <p><b>POSTCONDITION:</b> Task is no longer in the system.
     *
     * @param taskId the ID of the task to remove (must not be null)
     * @throws taskmanager.exception.TaskNotFoundException if no task with this ID exists
     */
    void removeTask(String taskId);

    /**
     * Returns all stored tasks as a plain list.
     *
     * <p><b>POSTCONDITION:</b> Returns a snapshot; never null (may be empty).
     *
     * @return list of all tasks
     */
    List<Task> getTasks();

    /**
     * Fetches real-time weather for the given city without blocking the UI.
     *
     * <p><b>PRECONDITION:</b> location must be a valid city name (e.g., "Jeddah").
     * <p><b>POSTCONDITION:</b> Emits a WeatherForecast on success, or an error on failure.
     *
     * @param location city name (must not be null)
     * @return {@code Mono<WeatherForecast>} running on a background thread
     * @throws taskmanager.exception.WeatherAPIException if the API call fails
     */
    Mono<WeatherForecast> fetchWeather(String location);

    /**
     * Returns the planner used to generate weather-aware schedule suggestions.
     *
     * @return the {@link SchedulePlanner} instance; never null
     */
    SchedulePlanner getPlanner();

    /**
     * Creates a new builder to configure and build a {@link TaskManager}.
     *
     * @return a fresh {@link TaskManagerBuilder} instance
     */
    static TaskManagerBuilder builder() {
        return new DefaultTaskManagerBuilder();
    }

    /**
     * Builder interface for constructing a {@link TaskManager} step by step.
     */
    interface TaskManagerBuilder {

        /**
         * Sets the OpenWeatherMap API key for weather fetching.
         *
         * @param apiKey your OpenWeatherMap API key (must not be null)
         * @return this builder (for chaining)
         */
        TaskManagerBuilder withWeatherApiKey(String apiKey);

        /**
         * Sets an optional file path for persistent task storage.
         *
         * @param path file path for storage (optional; ignored in this in-memory implementation)
         * @return this builder (for chaining)
         */
        TaskManagerBuilder withStoragePath(String path);

        /**
         * Builds and returns a fully configured {@link TaskManager}.
         *
         * <p><b>PRECONDITION:</b> {@code withWeatherApiKey} should be called before build.
         *
         * @return a new TaskManager instance ready to use
         */
        TaskManager build();
    }
}