package taskmanager.api;

import taskmanager.impl.DefaultTaskManager;

/**
 * Concrete implementation of {@link taskmanager.api.TaskManager.TaskManagerBuilder}.
 *
 * <p>Used internally by {@link TaskManager#builder()} to let callers configure
 * and build a {@link TaskManager} step by step. Example:
 * <pre>
 *   TaskManager tm = TaskManager.builder()
 *       .withWeatherApiKey("your_key")
 *       .build();
 * </pre>
 *
 * <p><b>Thread Safety:</b> This class is NOT thread-safe. It is intended to be
 * used by a single thread during application startup.
 */
public class DefaultTaskManagerBuilder implements TaskManager.TaskManagerBuilder {

    /** The OpenWeatherMap API key to use when building the TaskManager. */
    private String weatherApiKey;

    /**
     * Sets the OpenWeatherMap API key for weather fetching.
     *
     * <p><b>PRECONDITION:</b> apiKey should not be null (a null key will cause API errors at runtime).
     * <p><b>POSTCONDITION:</b> The given key is stored and will be passed to the TaskManager on build.
     * <p><b>SIDE EFFECTS:</b> Stores the key in this builder instance.
     *
     * @param apiKey the OpenWeatherMap API key (must not be null)
     * @return this builder (for chaining)
     */
    @Override
    public TaskManager.TaskManagerBuilder withWeatherApiKey(String apiKey) {
        this.weatherApiKey = apiKey;
        return this;
    }

    /**
     * Sets an optional file path for persistent task storage.
     *
     * <p><b>PRECONDITION:</b> None — this parameter is optional.
     * <p><b>POSTCONDITION:</b> No effect; this implementation uses in-memory storage only.
     * <p><b>SIDE EFFECTS:</b> None.
     *
     * @param path the file path for storage (optional; ignored in this in-memory implementation)
     * @return this builder (for chaining)
     */
    @Override
    public TaskManager.TaskManagerBuilder withStoragePath(String path) {
        // storage is optional; not used in this in-memory implementation
        return this;
    }

    /**
     * Builds and returns a fully configured {@link TaskManager}.
     *
     * <p><b>PRECONDITION:</b> {@code withWeatherApiKey} should be called before build;
     * otherwise the weather API will not work correctly.
     * <p><b>POSTCONDITION:</b> Returns a ready-to-use TaskManager instance.
     * <p><b>SIDE EFFECTS:</b> Creates new instances of WeatherService, DefaultTaskService,
     * and DefaultSchedulePlanner internally.
     *
     * @return a new {@link DefaultTaskManager} instance ready to use
     */
    @Override
    public TaskManager build() {
        return new DefaultTaskManager(weatherApiKey);
    }
}
