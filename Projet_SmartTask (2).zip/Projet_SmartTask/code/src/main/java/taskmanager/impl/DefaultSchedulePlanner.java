package taskmanager.impl;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import taskmanager.api.SchedulePlanner;
import taskmanager.api.ScheduleRecommendation;
import taskmanager.model.Task;
import taskmanager.model.WeatherForecast;
import taskmanager.service.WeatherService;

import java.util.List;

/**
 * Default implementation of {@link SchedulePlanner}.
 *
 * <p>Evaluates each task against current weather conditions and returns
 * a recommendation: SAFE, WARNING (rain &gt; 60%), or WARNING (heat &gt; 40°C).
 * Tasks that are not weather-sensitive always receive an "OK" recommendation.
 *
 * <p><b>Thread Safety:</b> This class is thread-safe. All reactive operations
 * run on background threads via Project Reactor.
 */
public class DefaultSchedulePlanner implements SchedulePlanner {

    /** Service used to fetch real-time weather data by location. */
    private final WeatherService weatherService;

    /**
     * Constructs a DefaultSchedulePlanner with access to the weather service.
     *
     * <p><b>PRECONDITION:</b> weatherService must not be null.
     * <p><b>POSTCONDITION:</b> Planner is ready to generate schedule recommendations.
     *
     * @param weatherService the service used to fetch weather data (must not be null)
     */
    public DefaultSchedulePlanner(WeatherService weatherService) {
        this.weatherService = weatherService;
    }

    /**
     * Suggests a schedule for the given tasks based on an existing weather forecast.
     *
     * <p><b>PRECONDITION:</b> tasks and forecast must not be null.
     * <p><b>POSTCONDITION:</b> Returns one recommendation per task in the input list.
     * <p><b>SIDE EFFECTS:</b> None — does not modify tasks or forecast.
     *
     * @param tasks    the list of tasks to evaluate (must not be null)
     * @param forecast the current weather forecast to evaluate against (must not be null)
     * @return {@code Mono<List<ScheduleRecommendation>>} with one entry per task
     */
    @Override
    public Mono<List<ScheduleRecommendation>> suggestSchedule(List<Task> tasks, WeatherForecast forecast) {
        return Flux.fromIterable(tasks)
                .map(task -> evaluate(task, forecast))
                .collectList();
    }

    /**
     * Fetches weather for the given location, then evaluates all tasks against it.
     *
     * <p><b>PRECONDITION:</b> tasks and location must not be null. location must be a valid city name.
     * <p><b>POSTCONDITION:</b> Returns one recommendation per task. If the weather fetch fails,
     * each task receives a fallback "Weather unavailable" message instead of an error.
     * <p><b>SIDE EFFECTS:</b> May trigger a network call via WeatherService.
     *
     * @param tasks    the list of tasks to evaluate (must not be null)
     * @param location city name to fetch weather for (e.g., "Jeddah"; must not be null)
     * @return {@code Mono<List<ScheduleRecommendation>>} with one entry per task
     */
    @Override
    public Mono<List<ScheduleRecommendation>> suggestScheduleForLocation(List<Task> tasks, String location) {
        return weatherService.fetchWeather(location)
                .flatMap(forecast -> suggestSchedule(tasks, forecast))
                .onErrorReturn(tasks.stream()
                        .map(t -> new ScheduleRecommendation(t, "Weather unavailable — please try again."))
                        .collect(java.util.stream.Collectors.toList()));
    }

    /**
     * Evaluates a single task against the weather and returns a recommendation.
     *
     * <p><b>PRECONDITION:</b> task and forecast must not be null.
     * <p><b>POSTCONDITION:</b> Returns one of: "OK", "WARNING (rain)", or "WARNING (heat)".
     * <p><b>SIDE EFFECTS:</b> None.
     *
     * @param task     the task to evaluate (must not be null)
     * @param forecast the weather data to check against (must not be null)
     * @return a {@link ScheduleRecommendation} with scheduling advice for the task
     */
    private ScheduleRecommendation evaluate(Task task, WeatherForecast forecast) {

        if (!task.isWeatherSensitive()) {
            return new ScheduleRecommendation(task, "OK - Task is not weather-sensitive.");
        }

        double rain = forecast.getPrecipitationProbability();
        double temp = forecast.getTemperatureCelsius();

        if (rain > 0.6) {
            return new ScheduleRecommendation(task,
                    "WARNING: High rain probability (" + (int)(rain * 100) + "%). Consider rescheduling.");
        }

        if (temp > 40) {
            return new ScheduleRecommendation(task,
                    "WARNING: Extreme heat (" + temp + "°C). Consider rescheduling.");
        }

        return new ScheduleRecommendation(task, "SAFE - Weather conditions are suitable.");
    }
}
