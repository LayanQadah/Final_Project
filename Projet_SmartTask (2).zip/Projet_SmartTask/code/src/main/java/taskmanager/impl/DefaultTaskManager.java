package taskmanager.impl;

import reactor.core.publisher.Mono;
import taskmanager.api.SchedulePlanner;
import taskmanager.api.TaskManager;
import taskmanager.service.TaskService;
import taskmanager.model.Task;
import taskmanager.model.WeatherForecast;
import taskmanager.service.WeatherService;

import java.util.List;

/**
 * Default implementation of {@link TaskManager} — the main facade of the system.
 *
 * <p>Connects the three core components: {@link DefaultTaskService} for task storage,
 * {@link DefaultSchedulePlanner} for weather-aware scheduling, and
 * {@link WeatherService} for real-time weather data.
 *
 * <p>This class is created via {@link taskmanager.api.DefaultTaskManagerBuilder}
 * using the Builder pattern, which keeps construction clean and readable.
 *
 * <p><b>Thread Safety:</b> Thread-safe. All heavy operations run on
 * background threads; the UI is never blocked.
 */
public class DefaultTaskManager implements TaskManager {

    /** Manages in-memory task storage with thread-safe reactive operations. */
    private final DefaultTaskService taskService;

    /** Generates weather-aware schedule recommendations for tasks. */
    private final DefaultSchedulePlanner schedulePlanner;

    /** Fetches real-time weather data from OpenWeatherMap API. */
    private final WeatherService weatherService;

    /**
     * Constructs a DefaultTaskManager and initializes all internal components.
     *
     * <p><b>PRECONDITION:</b> weatherApiKey must not be null (may be empty, but will cause API errors).
     * <p><b>POSTCONDITION:</b> All internal services are ready for use.
     * <p><b>SIDE EFFECTS:</b> Creates new instances of WeatherService, DefaultTaskService,
     * and DefaultSchedulePlanner.
     *
     * @param weatherApiKey the OpenWeatherMap API key (must not be null)
     */
    public DefaultTaskManager(String weatherApiKey) {
        this.weatherService   = new WeatherService(weatherApiKey);
        this.taskService      = new DefaultTaskService();
        this.schedulePlanner  = new DefaultSchedulePlanner(weatherService);
    }

    /**
     * Adds a task to the system synchronously.
     *
     * <p><b>PRECONDITION:</b> task must not be null; task title must not be blank.
     * <p><b>POSTCONDITION:</b> Task is stored and retrievable via {@link #getTasks()}.
     * <p><b>SIDE EFFECTS:</b> Modifies the internal task list.
     *
     * @param task the task to add (must not be null)
     * @throws taskmanager.exception.InvalidTaskException if task or its title is null/blank
     */
    @Override
    public void addTask(Task task) {
        taskService.addTask(task).block();
    }

    /**
     * Removes the task with the given ID from the system synchronously.
     *
     * <p><b>PRECONDITION:</b> taskId must not be null and must correspond to an existing task.
     * <p><b>POSTCONDITION:</b> The task with the given ID is no longer in the system.
     * <p><b>SIDE EFFECTS:</b> Modifies the internal task list.
     *
     * @param taskId the ID of the task to remove (must not be null)
     * @throws taskmanager.exception.TaskNotFoundException if no task with the given ID exists
     */
    @Override
    public void removeTask(String taskId) {
        taskService.removeTask(taskId).block();
    }

    /**
     * Returns all currently stored tasks as a plain list.
     *
     * <p><b>PRECONDITION:</b> None.
     * <p><b>POSTCONDITION:</b> Returns a snapshot of current tasks; may be empty but never null.
     * <p><b>SIDE EFFECTS:</b> None — returns a copy.
     *
     * @return list of all tasks; never null
     */
    @Override
    public List<Task> getTasks() {
        return taskService.findAllTasksAsList().block();
    }

    /**
     * Fetches real-time weather for the given city asynchronously.
     *
     * <p><b>PRECONDITION:</b> location must not be null and must be a valid city name.
     * <p><b>POSTCONDITION:</b> Returns a Mono that emits the weather forecast on success,
     * or emits a {@link taskmanager.exception.WeatherAPIException} on failure.
     * <p><b>SIDE EFFECTS:</b> May cache the result in WeatherService for subsequent calls.
     *
     * @param location city name (e.g., "Jeddah"; must not be null)
     * @return {@code Mono<WeatherForecast>} that runs on a background thread
     * @throws taskmanager.exception.WeatherAPIException if the API call fails
     */
    @Override
    public Mono<WeatherForecast> fetchWeather(String location) {
        return weatherService.fetchWeather(location);
    }

    /**
     * Returns the SchedulePlanner used for weather-aware task recommendations.
     *
     * <p><b>POSTCONDITION:</b> Never returns null.
     *
     * @return the internal {@link SchedulePlanner} instance
     */
    @Override
    public SchedulePlanner getPlanner() {
        return schedulePlanner;
    }

    /**
     * Exposes the internal TaskService for direct reactive use by the UI layer.
     *
     * <p><b>POSTCONDITION:</b> Never returns null.
     *
     * @return the internal {@link TaskService} instance
     */
    public TaskService getTaskService() {
        return taskService;
    }
}
