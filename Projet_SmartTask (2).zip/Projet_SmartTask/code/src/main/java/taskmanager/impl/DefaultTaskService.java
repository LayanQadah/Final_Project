package taskmanager.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import taskmanager.exception.InvalidTaskException;
import taskmanager.exception.TaskNotFoundException;
import taskmanager.model.Task;
import taskmanager.service.TaskService;

/**
 * Default in-memory implementation of {@link TaskService}.
 *
 * <p>Stores tasks in a thread-safe {@code CopyOnWriteArrayList}, which allows
 * safe concurrent reads without explicit locking.
 *
 * <p><b>Thread Safety:</b> This class is thread-safe. The underlying list
 * ({@code CopyOnWriteArrayList}) handles concurrent access safely.
 */
public class DefaultTaskService implements TaskService {

    /**
     * In-memory list of tasks.
     * CopyOnWriteArrayList ensures thread-safe access across multiple threads.
     */
    private final List<Task> tasks = new CopyOnWriteArrayList<>();

    /**
     * Adds a task to the in-memory list.
     *
     * <p><b>PRECONDITION:</b> task must not be null, and task.getTitle() must not be null or blank.
     * <p><b>POSTCONDITION:</b> The task is added to the list; tasks.size() increases by 1.
     * <p><b>SIDE EFFECTS:</b> Modifies the internal tasks list.
     *
     * @param task the task to add (must not be null, title must not be blank)
     * @return {@code Mono<Void>} that completes when the task is added
     * @throws InvalidTaskException if task is null or its title is null or blank
     */
    @Override
    public Mono<Void> addTask(Task task) {
        return Mono.fromRunnable(() -> {
            if (task == null || task.getTitle() == null || task.getTitle().isBlank()) {
                throw new InvalidTaskException("Task title cannot be null or empty");
            }
            tasks.add(task);
        });
    }

    /**
     * Removes the task with the given ID from the list.
     *
     * <p><b>PRECONDITION:</b> taskId must not be null.
     * <p><b>POSTCONDITION:</b> If the task existed, it is removed; tasks.size() decreases by 1.
     * <p><b>SIDE EFFECTS:</b> Modifies the internal tasks list.
     *
     * @param taskId the ID of the task to remove (must not be null)
     * @return {@code Mono<Void>} that completes when the task is removed
     * @throws TaskNotFoundException if no task with the given ID exists
     */
    @Override
    public Mono<Void> removeTask(String taskId) {
        return Mono.fromRunnable(() -> {
            boolean removed = tasks.removeIf(t -> t.getId().equals(taskId));
            if (!removed) {
                throw new TaskNotFoundException(taskId);
            }
        });
    }

    /**
     * Finds and returns a single task by its ID.
     *
     * <p><b>PRECONDITION:</b> taskId must not be null.
     * <p><b>POSTCONDITION:</b> Returns the task if found; emits an error otherwise.
     * <p><b>SIDE EFFECTS:</b> None — read-only operation.
     *
     * @param taskId the ID of the task to find (must not be null)
     * @return {@code Mono<Task>} emitting the task, or an error if not found
     * @throws TaskNotFoundException if no task with the given ID exists
     */
    @Override
    public Mono<Task> findTaskById(String taskId) {
        return Mono.fromCallable(() ->
            tasks.stream()
                .filter(t -> t.getId().equals(taskId))
                .findFirst()
                .orElseThrow(() -> new TaskNotFoundException(taskId))
        );
    }

    /**
     * Returns all valid tasks as a reactive stream.
     *
     * <p><b>PRECONDITION:</b> None.
     * <p><b>POSTCONDITION:</b> Only tasks with non-null and non-blank titles are emitted.
     * <p><b>SIDE EFFECTS:</b> None — read-only operation.
     *
     * @return {@code Flux<Task>} emitting all valid tasks (tasks with blank titles are filtered out)
     */
    @Override
    public Flux<Task> findAllTasks() {
        return Flux.fromIterable(tasks)
                .filter(task -> task != null && task.getTitle() != null && !task.getTitle().isBlank());
    }

    /**
     * Returns all tasks as a {@code List} wrapped in a {@code Mono}.
     *
     * <p><b>PRECONDITION:</b> None.
     * <p><b>POSTCONDITION:</b> Returns a snapshot copy of the current task list.
     * <p><b>SIDE EFFECTS:</b> None — returns a copy, not the internal list.
     *
     * @return {@code Mono<List<Task>>} emitting a copy of all stored tasks
     */
    @Override
    public Mono<List<Task>> findAllTasksAsList() {
        return Mono.fromCallable(() -> new ArrayList<>(tasks));
    }
}
