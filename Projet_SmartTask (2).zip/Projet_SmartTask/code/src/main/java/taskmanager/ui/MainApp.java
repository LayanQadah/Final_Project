package taskmanager.ui;

import java.time.LocalDateTime;

import taskmanager.api.TaskManager;
import taskmanager.model.Task;

/**
 * Entry point for the Smart Task Manager application.
 *
 * <p>Builds a {@link TaskManager}, loads two sample tasks,
 * and launches the Swing UI on the Event Dispatch Thread (EDT).
 *
 * <p><b>Thread Safety:</b> The UI is always started on the EDT via
 * {@code SwingUtilities.invokeLater()} to follow Swing's threading rules.
 */
public class MainApp {

    /**
     * Application entry point.
     *
     * <p><b>PRECONDITION:</b> None — no arguments are required.
     * <p><b>POSTCONDITION:</b> The Swing window is visible and two sample tasks are loaded.
     * <p><b>SIDE EFFECTS:</b> Creates a TaskManager, adds two tasks, and opens the UI window.
     *
     * @param args command-line arguments (not used)
     */
    public static void main(String[] args) {
        // Build the TaskManager with the OpenWeatherMap API key
        TaskManager tm = TaskManager.builder()
                .withWeatherApiKey("d8daee791571d16c8054f6e8f158542e")
                .build();

        // Add two sample tasks to demonstrate the system
        Task task1 = new Task(
                "task-001",
                "Morning run",
                LocalDateTime.now().plusHours(2),
                true
        );
        Task task2 = new Task(
                "task-002",
                "Coding session",
                LocalDateTime.now().plusHours(4),
                false
        );

        tm.addTask(task1);
        tm.addTask(task2);

        System.out.println("Tasks loaded: " + tm.getTasks().size());

        // Launch the Swing UI on the Event Dispatch Thread
        SmartTaskManagerFrame frame = new SmartTaskManagerFrame(tm);
        javax.swing.SwingUtilities.invokeLater(() -> frame.setVisible(true));
    }
}
