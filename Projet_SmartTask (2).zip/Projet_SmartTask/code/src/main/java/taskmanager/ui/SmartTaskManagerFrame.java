package taskmanager.ui;

import taskmanager.api.TaskManager;
import taskmanager.api.SchedulePlanner;
import taskmanager.api.ScheduleRecommendation;
import taskmanager.service.TaskService;
import taskmanager.model.Task;
import taskmanager.model.WeatherForecast;

import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.UUID;

/**
 * The main Swing window for the Smart Task Manager application.
 *
 * <p>Displays all tasks in a table and provides buttons to add, edit,
 * delete tasks, fetch real-time weather, and get schedule suggestions.
 *
 * <p><b>Thread Safety:</b> All UI updates run on the Event Dispatch Thread (EDT)
 * via {@code SwingUtilities.invokeLater()}. All background work (weather, task I/O)
 * runs on {@code Schedulers.boundedElastic()} to avoid blocking the UI.
 */
public class SmartTaskManagerFrame extends JFrame {

    /** The main TaskManager facade used to access all system features. */
    private final TaskManager taskManager;

    /** Direct access to the reactive TaskService for add/remove/find operations. */
    private final TaskService taskService;

    /** Used to generate weather-aware schedule suggestions. */
    private final SchedulePlanner schedulePlanner;

    /** Table that displays the task list. */
    private final JTable taskTable;

    /** Data model behind the task table. */
    private final DefaultTableModel tableModel;

    // Buttons for user actions
    private final JButton updateWeatherButton;
    private final JButton addTaskButton;
    private final JButton editTaskButton;
    private final JButton deleteTaskButton;
    private final JButton suggestScheduleButton;

    /** Status bar label shown at the top of the window. */
    private final JLabel statusLabel;

    /** Column headers for the task table. */
    private final String[] columnNames = {"ID", "Title", "Due Time", "Weather Sensitive", "Status"};

    /** Date-time format used in the add/edit dialogs. */
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    /**
     * Constructs and initializes the main application window.
     *
     * <p><b>PRECONDITION:</b> taskManager must not be null and must be a DefaultTaskManager.
     * <p><b>POSTCONDITION:</b> Window is built and tasks are loaded into the table.
     * <p><b>SIDE EFFECTS:</b> Sets window size, attaches event listeners, loads tasks from TaskManager.
     *
     * @param taskManager the fully configured TaskManager instance (must not be null)
     */
    public SmartTaskManagerFrame(TaskManager taskManager) {
        this.taskManager    = taskManager;
        this.taskService    = ((taskmanager.impl.DefaultTaskManager) taskManager).getTaskService();
        this.schedulePlanner = taskManager.getPlanner();

        setTitle("Smart Task Manager (Swing)");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(800, 500);

        tableModel = new DefaultTableModel(columnNames, 0);
        taskTable  = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(taskTable);

        addTaskButton         = new JButton("Add Task");
        editTaskButton        = new JButton("Edit Task");
        deleteTaskButton      = new JButton("Delete Task");
        updateWeatherButton   = new JButton("Update Weather");
        suggestScheduleButton = new JButton("Suggest Schedule");

        // Buttons that require a row selection are disabled until the user selects a task
        editTaskButton.setEnabled(false);
        deleteTaskButton.setEnabled(false);
        updateWeatherButton.setEnabled(false);
        suggestScheduleButton.setEnabled(false);

        statusLabel = new JLabel("Ready");

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.add(addTaskButton);
        buttonPanel.add(editTaskButton);
        buttonPanel.add(deleteTaskButton);
        buttonPanel.add(updateWeatherButton);
        buttonPanel.add(suggestScheduleButton);

        setLayout(new BorderLayout());
        add(scrollPane,   BorderLayout.CENTER);
        add(buttonPanel,  BorderLayout.SOUTH);
        add(statusLabel,  BorderLayout.NORTH);

        loadTasks();

        // Enable row-dependent buttons only when a row is selected
        taskTable.getSelectionModel().addListSelectionListener(e -> {
            boolean rowSelected = taskTable.getSelectedRow() >= 0;
            editTaskButton.setEnabled(rowSelected);
            deleteTaskButton.setEnabled(rowSelected);
            updateWeatherButton.setEnabled(rowSelected);
            suggestScheduleButton.setEnabled(rowSelected);
        });

        addTaskButton.addActionListener(e -> showAddTaskDialog());
        editTaskButton.addActionListener(e -> showEditTaskDialog());
        deleteTaskButton.addActionListener(e -> deleteSelectedTask());
        updateWeatherButton.addActionListener(e -> {
            int row = taskTable.getSelectedRow();
            if (row >= 0) updateWeatherForTask((String) tableModel.getValueAt(row, 0));
        });
        suggestScheduleButton.addActionListener(e -> suggestSchedule());
    }

    /**
     * Loads all tasks from the TaskManager and fills the table.
     *
     * <p><b>PRECONDITION:</b> taskManager must be initialized.
     * <p><b>POSTCONDITION:</b> Table is refreshed with the latest task data.
     * <p><b>SIDE EFFECTS:</b> Clears the table and refills it on the EDT.
     */
    private void loadTasks() {
        Mono.just(taskManager.getTasks())
                .subscribeOn(Schedulers.boundedElastic())
                .doOnNext(tasks -> SwingUtilities.invokeLater(() -> populateTable(tasks)))
                .subscribe();
    }

    /**
     * Fills the table model with the given list of tasks.
     *
     * <p><b>PRECONDITION:</b> tasks must not be null. Must be called on the EDT.
     * <p><b>POSTCONDITION:</b> Table rows are replaced with the given tasks.
     * <p><b>SIDE EFFECTS:</b> Clears all existing rows and adds new ones.
     *
     * @param tasks the list of tasks to display (must not be null)
     */
    private void populateTable(List<Task> tasks) {
        tableModel.setRowCount(0);
        for (Task t : tasks) {
            tableModel.addRow(new Object[]{
                t.getId(), t.getTitle(), t.getDueDateTime(), t.isWeatherSensitive(), "N/A"
            });
        }
    }

    /**
     * Opens a dialog for the user to enter a new task, then adds it.
     *
     * <p><b>PRECONDITION:</b> None.
     * <p><b>POSTCONDITION:</b> If the user confirms, the new task is added and the table is refreshed.
     * <p><b>SIDE EFFECTS:</b> Shows a dialog; modifies the task list; updates the table and status label.
     */
    private void showAddTaskDialog() {
        JTextField idField    = new JTextField(UUID.randomUUID().toString().substring(0, 8));
        JTextField titleField = new JTextField();
        JTextField dateField  = new JTextField(LocalDateTime.now().plusHours(1).format(FORMATTER));
        JCheckBox  weatherBox = new JCheckBox("Weather Sensitive");

        JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));
        panel.add(new JLabel("ID:"));                        panel.add(idField);
        panel.add(new JLabel("Title:"));                     panel.add(titleField);
        panel.add(new JLabel("Due (yyyy-MM-dd HH:mm):"));   panel.add(dateField);
        panel.add(new JLabel(""));                           panel.add(weatherBox);

        int result = JOptionPane.showConfirmDialog(this, panel, "Add Task",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result != JOptionPane.OK_OPTION) return;

        try {
            LocalDateTime due = LocalDateTime.parse(dateField.getText().trim(), FORMATTER);
            Task newTask = new Task(idField.getText().trim(), titleField.getText().trim(),
                    due, weatherBox.isSelected());

            taskService.addTask(newTask)
                    .subscribeOn(Schedulers.boundedElastic())
                    .doOnSuccess(v -> SwingUtilities.invokeLater(() -> {
                        loadTasks();
                        statusLabel.setText("Task added: " + newTask.getTitle());
                    }))
                    .doOnError(err -> SwingUtilities.invokeLater(() ->
                            JOptionPane.showMessageDialog(this, err.getMessage(),
                                    "Error", JOptionPane.ERROR_MESSAGE)))
                    .subscribe();

        } catch (DateTimeParseException ex) {
            JOptionPane.showMessageDialog(this,
                    "Invalid date format. Use: yyyy-MM-dd HH:mm",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Opens a dialog for the user to edit the selected task.
     *
     * <p><b>PRECONDITION:</b> A row must be selected in the table.
     * <p><b>POSTCONDITION:</b> If the user confirms, the task fields are updated and the table refreshes.
     * <p><b>SIDE EFFECTS:</b> Shows a dialog; modifies the task in memory; updates the table and status label.
     */
    private void showEditTaskDialog() {
        int row = taskTable.getSelectedRow();
        if (row < 0) return;

        String  taskId         = (String)  tableModel.getValueAt(row, 0);
        String  currentTitle   = (String)  tableModel.getValueAt(row, 1);
        boolean currentWeather = (boolean) tableModel.getValueAt(row, 3);

        JTextField titleField = new JTextField(currentTitle);
        JTextField dateField  = new JTextField(LocalDateTime.now().plusHours(1).format(FORMATTER));
        JCheckBox  weatherBox = new JCheckBox("Weather Sensitive", currentWeather);

        JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));
        panel.add(new JLabel("Title:"));                     panel.add(titleField);
        panel.add(new JLabel("Due (yyyy-MM-dd HH:mm):"));   panel.add(dateField);
        panel.add(new JLabel(""));                           panel.add(weatherBox);

        int result = JOptionPane.showConfirmDialog(this, panel, "Edit Task",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result != JOptionPane.OK_OPTION) return;

        taskService.findTaskById(taskId)
                .subscribeOn(Schedulers.boundedElastic())
                .doOnNext(task -> {
                    try {
                        task.setTitle(titleField.getText().trim());
                        task.setDueDateTime(LocalDateTime.parse(dateField.getText().trim(), FORMATTER));
                        task.setWeatherSensitive(weatherBox.isSelected());
                    } catch (DateTimeParseException ignored) { }

                    SwingUtilities.invokeLater(() -> {
                        loadTasks();
                        statusLabel.setText("Task updated: " + task.getTitle());
                    });
                })
                .doOnError(err -> SwingUtilities.invokeLater(() ->
                        JOptionPane.showMessageDialog(this, err.getMessage(),
                                "Error", JOptionPane.ERROR_MESSAGE)))
                .subscribe();
    }

    /**
     * Asks the user to confirm, then deletes the selected task.
     *
     * <p><b>PRECONDITION:</b> A row must be selected in the table.
     * <p><b>POSTCONDITION:</b> If confirmed, the task is removed and the table refreshes.
     * <p><b>SIDE EFFECTS:</b> Shows a confirmation dialog; removes the task from storage;
     * updates the table and status label.
     */
    private void deleteSelectedTask() {
        int row = taskTable.getSelectedRow();
        if (row < 0) return;

        String taskId    = (String) tableModel.getValueAt(row, 0);
        String taskTitle = (String) tableModel.getValueAt(row, 1);

        int confirm = JOptionPane.showConfirmDialog(this,
                "Delete task: \"" + taskTitle + "\"?",
                "Confirm Delete", JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION) return;

        taskService.removeTask(taskId)
                .subscribeOn(Schedulers.boundedElastic())
                .doOnSuccess(v -> SwingUtilities.invokeLater(() -> {
                    loadTasks();
                    statusLabel.setText("Task deleted: " + taskTitle);
                }))
                .doOnError(err -> SwingUtilities.invokeLater(() ->
                        JOptionPane.showMessageDialog(this, err.getMessage(),
                                "Error", JOptionPane.ERROR_MESSAGE)))
                .subscribe();
    }

    /**
     * Fetches weather for Jeddah and shows schedule suggestions for all tasks.
     *
     * <p><b>PRECONDITION:</b> None.
     * <p><b>POSTCONDITION:</b> A dialog is shown with one recommendation per task.
     * <p><b>SIDE EFFECTS:</b> Triggers a weather API call; shows a result dialog;
     * updates the status label.
     */
    private void suggestSchedule() {
        List<Task> tasks = taskManager.getTasks();

        schedulePlanner.suggestScheduleForLocation(tasks, "Jeddah")
                .subscribeOn(Schedulers.boundedElastic())
                .doOnNext(recommendations -> SwingUtilities.invokeLater(() -> {
                    StringBuilder sb = new StringBuilder();
                    for (ScheduleRecommendation r : recommendations) {
                        sb.append("• ").append(r.task().getTitle())
                          .append(": ").append(r.recommendation()).append("\n");
                    }
                    JOptionPane.showMessageDialog(this, sb.toString(),
                            "Schedule Suggestions", JOptionPane.INFORMATION_MESSAGE);
                    statusLabel.setText("Schedule suggestions generated.");
                }))
                .doOnError(err -> SwingUtilities.invokeLater(() -> {
                    JOptionPane.showMessageDialog(this, err.getMessage(),
                            "Error", JOptionPane.ERROR_MESSAGE);
                    statusLabel.setText("Suggestion failed: " + err.getMessage());
                }))
                .subscribe();
    }

    /**
     * Fetches real-time weather for Jeddah and updates the status column for the given task.
     *
     * <p><b>PRECONDITION:</b> taskId must match a row in the table.
     * <p><b>POSTCONDITION:</b> The "Status" column for the task is updated to "SAFE" or "RISKY (rain)".
     * <p><b>SIDE EFFECTS:</b> Triggers a weather API call; updates the table cell; updates the status label.
     *
     * @param taskId the ID of the task whose status should be updated (must not be null)
     */
    private void updateWeatherForTask(String taskId) {
        Mono<WeatherForecast> forecastMono = taskManager.fetchWeather("Jeddah");

        forecastMono
                .subscribeOn(Schedulers.boundedElastic())
                .doOnNext(forecast -> SwingUtilities.invokeLater(() -> {
                    String status = forecast.getPrecipitationProbability() > 0.6
                            ? "RISKY (rain)" : "SAFE";
                    updateTaskStatusInTable(taskId, status);
                    statusLabel.setText("Weather updated for task: " + taskId);
                }))
                .doOnError(error -> SwingUtilities.invokeLater(() -> {
                        JOptionPane.showMessageDialog(this, error.getMessage(),
                                "Error", JOptionPane.ERROR_MESSAGE);
                        statusLabel.setText("Weather fetch failed: " + error.getMessage());
                }))
                .subscribe();
    }

    /**
     * Updates the "Status" column for the row matching the given task ID.
     *
     * <p><b>PRECONDITION:</b> taskId must match an existing row. Must be called on the EDT.
     * <p><b>POSTCONDITION:</b> The matching row's Status cell is set to the given status string.
     * <p><b>SIDE EFFECTS:</b> Modifies one cell in the table model.
     *
     * @param taskId the ID of the task to update (must not be null)
     * @param status the new status string to display (e.g., "SAFE" or "RISKY (rain)")
     */
    private void updateTaskStatusInTable(String taskId, String status) {
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            if (tableModel.getValueAt(i, 0).equals(taskId)) {
                tableModel.setValueAt(status, i, 4);
                break;
            }
        }
    }
}
