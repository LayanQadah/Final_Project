package taskmanager.service;

import java.util.List;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import taskmanager.model.Task;

/**
 * Defines the core operations for managing tasks in the system.
 *
 * <p>All methods return reactive types (Mono or Flux) so they can run
 * without blocking the UI thread.
 *
 * <p><b>Thread Safety:</b> Implementations must be thread-safe.
 */
public interface TaskService {

    /**
     * Adds a task to the system.
     *
     * <p><b>PRECONDITION:</b> task must not be null; task title must not be null or blank.
     * <p><b>POSTCONDITION:</b> Task is stored and will appear in future calls to
     * {@link #findAllTasks()} and {@link #findAllTasksAsList()}.
     * <p><b>SIDE EFFECTS:</b> Modifies the internal task list.
     *
     * @param task the task to add (must not be null)
     * @return {@code Mono<Void>} that completes when the task is added
     * @throws taskmanager.exception.InvalidTaskException if task is null or title is blank
     */
    Mono<Void> addTask(Task task);

    /**
     * Removes the task with the given ID from the system.
     *
     * <p><b>PRECONDITION:</b> taskId must not be null and must match an existing task.
     * <p><b>POSTCONDITION:</b> The task with the given ID is no longer in the system.
     * <p><b>SIDE EFFECTS:</b> Modifies the internal task list.
     *
     * @param taskId the ID of the task to remove (must not be null)
     * @return {@code Mono<Void>} that completes when the task is removed
     * @throws taskmanager.exception.TaskNotFoundException if no task with this ID exists
     */
    Mono<Void> removeTask(String taskId);

    /**
     * Finds and returns a single task by its ID.
     *
     * <p><b>PRECONDITION:</b> taskId must not be null.
     * <p><b>POSTCONDITION:</b> Emits the matching task if found; emits an error if not found.
     * <p><b>SIDE EFFECTS:</b> None — read-only operation.
     *
     * @param taskId the ID of the task to find (must not be null)
     * @return {@code Mono<Task>} emitting the task, or an error if not found
     * @throws taskmanager.exception.TaskNotFoundException if no task with this ID exists
     */
    Mono<Task> findTaskById(String taskId);

    /**
     * Returns all tasks as a reactive stream.
     *
     * <p><b>PRECONDITION:</b> None.
     * <p><b>POSTCONDITION:</b> Emits all valid tasks (tasks with blank titles are skipped).
     * <p><b>SIDE EFFECTS:</b> None — read-only operation.
     *
     * @return {@code Flux<Task>} emitting all valid stored tasks
     */
    Flux<Task> findAllTasks();

    /**
     * Returns all tasks as a plain list wrapped in a Mono.
     *
     * <p><b>PRECONDITION:</b> None.
     * <p><b>POSTCONDITION:</b> Emits a snapshot copy of all current tasks; never null.
     * <p><b>SIDE EFFECTS:</b> None — returns a copy, not the internal list.
     *
     * @return {@code Mono<List<Task>>} emitting a copy of all stored tasks
     */
    Mono<List<Task>> findAllTasksAsList();
}
