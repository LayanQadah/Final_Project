package taskmanager.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
import taskmanager.exception.WeatherAPIException;
import taskmanager.model.WeatherForecast;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.LocalDateTime;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Service responsible for fetching real-time weather data from the OpenWeatherMap API.
 *
 * <p>Results are cached in a {@code ConcurrentHashMap} to avoid redundant API calls
 * for the same location within the same session.
 *
 * <p><b>Thread Safety:</b> This class is thread-safe. The HTTP client and cache
 * are both thread-safe. Reactive operations run on {@code Schedulers.boundedElastic()}.
 */
public class WeatherService {

    /** Base URL for the OpenWeatherMap current weather endpoint. */
    private static final String BASE_URL =
            "https://api.openweathermap.org/data/2.5/weather";

    /** API key used to authenticate requests to OpenWeatherMap. */
    private final String apiKey;

    /** Java built-in HTTP client for sending requests (thread-safe). */
    private final HttpClient httpClient;

    /** Jackson object mapper for parsing JSON responses. */
    private final ObjectMapper objectMapper;

    /**
     * Cache mapping city name → WeatherForecast to avoid repeated API calls.
     * Uses ConcurrentHashMap for thread-safe access.
     */
    private final ConcurrentHashMap<String, WeatherForecast> cache;

    /**
     * Constructs a WeatherService with the given OpenWeatherMap API key.
     *
     * <p><b>PRECONDITION:</b> apiKey must not be null (an invalid key causes a 401 error at runtime).
     * <p><b>POSTCONDITION:</b> Service is ready to fetch weather data.
     * <p><b>SIDE EFFECTS:</b> Initializes HTTP client, JSON mapper, and empty cache.
     *
     * @param apiKey the OpenWeatherMap API key (must not be null)
     */
    public WeatherService(String apiKey) {
        this.apiKey = apiKey;
        this.httpClient = HttpClient.newHttpClient();
        this.objectMapper = new ObjectMapper();
        this.cache = new ConcurrentHashMap<>();
    }

    /**
     * Fetches the current weather for the given city.
     *
     * <p>Returns cached data immediately if this location was already fetched.
     * Otherwise, sends an HTTP GET request to OpenWeatherMap and parses the response.
     * The operation runs on a background thread and automatically retries once on failure.
     *
     * <p><b>PRECONDITION:</b> location must not be null and must be a valid city name.
     * <p><b>POSTCONDITION:</b> Returns a WeatherForecast for the given city,
     * and caches it for future calls with the same location.
     * <p><b>SIDE EFFECTS:</b> Sends an HTTP request; updates the internal cache.
     *
     * @param location the city name (e.g., "Jeddah"; must not be null)
     * @return {@code Mono<WeatherForecast>} running on a background thread
     * @throws WeatherAPIException if the API returns a non-200 status or the call fails
     */
    public Mono<WeatherForecast> fetchWeather(String location) {

        if (cache.containsKey(location)) {
            return Mono.just(cache.get(location));
        }

        return Mono.fromCallable(() -> {

            String url = BASE_URL + "?q=" + location + "&appid=" + apiKey + "&units=metric";

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .GET()
                    .build();

            HttpResponse<String> response =
                    httpClient.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() != 200) {
                throw new WeatherAPIException(
                        "Weather API error. Status: " + response.statusCode(), null);
            }

            WeatherForecast forecast = parseResponse(location, response.body());
            cache.put(location, forecast);
            return forecast;

        })
        .subscribeOn(Schedulers.boundedElastic())
        .retry(1)
        .onErrorMap(
                e -> !(e instanceof WeatherAPIException),
                e -> new WeatherAPIException("Failed to fetch weather for: " + location, e)
        );
    }

    /**
     * Parses the raw JSON response from OpenWeatherMap into a {@link WeatherForecast} object.
     *
     * <p><b>PRECONDITION:</b> location and json must not be null; json must be valid OpenWeatherMap JSON.
     * <p><b>POSTCONDITION:</b> Returns a fully populated WeatherForecast object.
     * <p><b>SIDE EFFECTS:</b> None.
     *
     * @param location the city name (used to populate the WeatherForecast)
     * @param json     the raw JSON string returned by the OpenWeatherMap API
     * @return a {@link WeatherForecast} built from the parsed JSON
     * @throws Exception if the JSON cannot be parsed
     */
    private WeatherForecast parseResponse(String location, String json) throws Exception {

        JsonNode root = objectMapper.readTree(json);

        String conditionRaw = root.path("weather").get(0).path("main").asText();
        String condition = conditionRaw.isEmpty() ? "Unknown" : conditionRaw;

        double temp = root.path("main").path("temp").asDouble(0.0);
        double precipitationProbability = estimatePrecipitation(condition);

        return new WeatherForecast(location, LocalDateTime.now(), temp, condition, precipitationProbability);
    }

    /**
     * Estimates precipitation probability based on the weather condition string.
     *
     * <p>The free OpenWeatherMap tier does not provide a direct precipitation probability,
     * so this method maps known condition strings to fixed probabilities.
     *
     * <p><b>PRECONDITION:</b> condition must not be null.
     * <p><b>POSTCONDITION:</b> Returns a value in the range [0.0, 1.0].
     * <p><b>SIDE EFFECTS:</b> None.
     *
     * @param condition weather condition from the API (e.g., "Rain", "Clear", "Clouds")
     * @return estimated precipitation probability between 0.0 (no rain) and 1.0 (certain rain)
     */
    private double estimatePrecipitation(String condition) {
        return switch (condition) {
            case "Thunderstorm", "Rain", "Drizzle" -> 0.85;
            case "Snow"                             -> 0.70;
            case "Clouds"                           -> 0.30;
            case "Clear"                            -> 0.05;
            default                                 -> 0.20;
        };
    }
}
